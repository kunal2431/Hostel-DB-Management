-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 03, 2019 at 08:43 AM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.3.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hostel`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `getregistration` ()  select * FROM registration$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(300) NOT NULL,
  `reg_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `updation_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `email`, `password`, `reg_date`, `updation_date`) VALUES
(3, 'lohith', 'lohith@gmail.com', 'lohith', '2019-11-21 05:59:21', '2019-11-21'),
(9, 'kunal', 'kunal@gmail.com', 'kunal', '2019-11-21 06:01:05', '2019-11-21');

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `id` int(11) NOT NULL,
  `course_code` varchar(255) NOT NULL,
  `course_sn` varchar(255) NOT NULL,
  `course_fn` varchar(255) NOT NULL,
  `posting_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`id`, `course_code`, `course_sn`, `course_fn`, `posting_date`) VALUES
(1, 'code@111', 'BE', 'Bachelor of Engineering', '2019-11-21 06:17:58'),
(2, 'code@112', 'BSC', 'Bachelor of Science', '2019-11-21 06:18:30'),
(3, 'code@113', 'Bcom', 'Bachelor of Commerce', '2019-11-21 06:19:09'),
(4, 'code@114', 'Bca', 'Bachelor of Computer Application', '2019-11-21 06:19:55'),
(5, 'code@115', 'BBM', 'Bachelor of Business Management', '2019-11-21 06:21:22'),
(6, 'code@116', 'BBA', 'Bachelor of Business Administration', '2019-11-21 06:23:48'),
(7, 'code@117', 'ME', 'Master of Engineering', '2019-11-21 06:24:50'),
(8, 'code@118', 'MBA', 'Master of Business Administration', '2019-11-21 06:25:27'),
(9, 'code@119', 'MSc', 'Master of Science', '2019-11-21 06:26:02'),
(10, 'code@120', 'MCA', 'Master of Computer Application', '2019-11-21 06:26:38');

-- --------------------------------------------------------

--
-- Table structure for table `logs`
--

CREATE TABLE `logs` (
  `id` int(11) NOT NULL,
  `reg_id` int(11) NOT NULL,
  `action` varchar(30) NOT NULL,
  `cdate` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `logs`
--

INSERT INTO `logs` (`id`, `reg_id`, `action`, `cdate`) VALUES
(1, 8, 'Inserted', '2019-11-22 11:29:22'),
(2, 7, 'Deleted', '2019-11-22 11:38:35'),
(3, 2, 'updated', '2019-11-22 11:40:54'),
(4, 1, 'updated', '2019-11-22 11:44:41'),
(5, 2, 'updated', '2019-11-22 11:45:23'),
(6, 3, 'updated', '2019-11-22 11:45:41'),
(7, 6, 'updated', '2019-11-22 11:46:06'),
(8, 5, 'updated', '2019-11-22 13:43:07'),
(9, 1, 'updated', '2019-12-03 12:47:00'),
(10, 2, 'updated', '2019-12-03 12:49:06'),
(11, 3, 'updated', '2019-12-03 12:49:06'),
(12, 5, 'updated', '2019-12-03 12:49:06'),
(13, 6, 'updated', '2019-12-03 12:49:06'),
(14, 1, 'updated', '2019-12-03 12:49:19'),
(15, 5, 'updated', '2019-12-03 12:49:31'),
(16, 6, 'updated', '2019-12-03 12:49:38'),
(17, 7, 'Inserted', '2019-12-03 12:56:18'),
(18, 7, 'Deleted', '2019-12-03 12:57:21'),
(19, 1, 'updated', '2019-12-03 13:05:15'),
(20, 1, 'updated', '2019-12-03 13:05:48'),
(21, 6, 'Deleted', '2019-12-03 13:12:08');

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `id` int(11) NOT NULL,
  `roomno` int(11) NOT NULL,
  `seater` int(11) NOT NULL,
  `feespm` int(11) NOT NULL,
  `foodstatus` int(11) NOT NULL,
  `stayfrom` date NOT NULL,
  `duration` int(11) NOT NULL,
  `course` varchar(500) NOT NULL,
  `regno` varchar(30) NOT NULL,
  `firstName` varchar(500) NOT NULL,
  `middleName` varchar(500) NOT NULL,
  `lastName` varchar(500) NOT NULL,
  `gender` varchar(250) NOT NULL,
  `contactno` bigint(11) NOT NULL,
  `emailid` varchar(500) NOT NULL,
  `egycontactno` bigint(11) NOT NULL,
  `guardianName` varchar(500) NOT NULL,
  `guardianRelation` varchar(500) NOT NULL,
  `guardianContactno` bigint(11) NOT NULL,
  `corresAddress` varchar(500) NOT NULL,
  `corresCIty` varchar(500) NOT NULL,
  `corresState` varchar(500) NOT NULL,
  `corresPincode` int(11) NOT NULL,
  `pmntAddress` varchar(500) NOT NULL,
  `pmntCity` varchar(500) NOT NULL,
  `pmnatetState` varchar(500) NOT NULL,
  `pmntPincode` int(11) NOT NULL,
  `postingDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `updationDate` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`id`, `roomno`, `seater`, `feespm`, `foodstatus`, `stayfrom`, `duration`, `course`, `regno`, `firstName`, `middleName`, `lastName`, `gender`, `contactno`, `emailid`, `egycontactno`, `guardianName`, `guardianRelation`, `guardianContactno`, `corresAddress`, `corresCIty`, `corresState`, `corresPincode`, `pmntAddress`, `pmntCity`, `pmnatetState`, `pmntPincode`, `postingDate`, `updationDate`) VALUES
(1, 201, 2, 5000, 1, '2019-11-22', 1, 'Bachelor of Engineering', '1sg17cs018', 'Anil', 'kumar', 'G', 'male', 9113847004, 'anilkumar@gmail.com', 7813851198, 'Girish kumar J', 'father', 9538235527, 'devinagar,kodigehalli. \r\nnear vyasa international school.', 'Bangalore', 'Karnataka', 560092, 'devinagar,kodigehalli. \r\nnear vyasa international school.', 'Bangalore', 'Karnataka', 560092, '2019-11-21 06:43:23', ''),
(2, 201, 2, 5000, 1, '2019-10-12', 2, 'Bachelor of Computer Application', '1sg17cs002', 'Abhijith', '', 'Uthaman', 'male', 914345236, 'abhijith080@gmail.com', 8214123452, 'srinivas', 'uncle', 9534412372, 'murugeshpalya,hal.', 'bangalore', 'Karnataka', 560042, '#120,1st street,4th main,knagar.', 'kottayam', 'Kerala', 230012, '2019-11-21 06:49:57', ''),
(3, 203, 2, 5000, 0, '2019-11-19', 1, 'Bachelor of Science', '1sg17cs019', 'Anirban', '', ' Dey', 'male', 8453413245, 'anirdey2@gmail.com', 9244554881, 'mala', 'aunt', 8854412382, '#680 silver farm, channsandra.', 'bangalore', 'Karnataka', 560067, '#22 ,dada street,m nagar.', 'kolkata', 'West Bengal', 450028, '2019-11-21 06:55:45', ''),
(5, 211, 1, 7000, 0, '2019-11-01', 1, 'Bachelor of Commerce', '1sg17cs025', 'Arijeet', '', ' Roy', 'male', 7225464222, 'arijeetroy98@gmail.com', 8388532245, 'raghu', 'brother', 9821596412, '#32 7th street,2nd main,tnagar.', 'chennai', 'Tamil Nadu', 110021, '#99 13p street,willasar nagar.', 'jhamsapur', 'Bihar', 620088, '2019-11-21 07:13:51', '');

--
-- Triggers `registration`
--
DELIMITER $$
CREATE TRIGGER `deleteLogs` AFTER DELETE ON `registration` FOR EACH ROW INSERT INTO logs VALUES(null, OLD.id, 'Deleted', NOW())
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `insertlogs` AFTER INSERT ON `registration` FOR EACH ROW insert into logs values(null, NEW.id,'Inserted',NOW())
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `updateLogs` AFTER UPDATE ON `registration` FOR EACH ROW insert into logs values(null, NEW.id,'updated',NOW())
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `rooms`
--

CREATE TABLE `rooms` (
  `id` int(11) NOT NULL,
  `seater` int(11) NOT NULL,
  `room_no` int(11) NOT NULL,
  `fees` int(11) NOT NULL,
  `posting_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rooms`
--

INSERT INTO `rooms` (`id`, `seater`, `room_no`, `fees`, `posting_date`) VALUES
(1, 2, 201, 5000, '2019-11-21 06:34:34'),
(6, 2, 202, 5000, '2019-11-21 06:35:05'),
(7, 2, 203, 5000, '2019-11-21 06:35:49'),
(8, 3, 204, 4000, '2019-11-21 06:36:11'),
(10, 3, 205, 4000, '2019-11-21 06:36:55'),
(11, 4, 206, 3200, '2019-11-21 06:37:25'),
(12, 4, 207, 3200, '2019-11-21 06:37:40'),
(13, 4, 208, 3200, '2019-11-21 06:37:54'),
(14, 5, 209, 2500, '2019-11-21 06:38:07'),
(15, 5, 210, 2500, '2019-11-21 06:38:23'),
(16, 1, 211, 7000, '2019-11-21 06:38:34'),
(17, 1, 212, 7000, '2019-11-21 06:38:47');

-- --------------------------------------------------------

--
-- Table structure for table `states`
--

CREATE TABLE `states` (
  `id` int(11) NOT NULL,
  `State` varchar(150) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `states`
--

INSERT INTO `states` (`id`, `State`) VALUES
(1, 'Andaman and Nicobar Island (UT)'),
(2, 'Andhra Pradesh'),
(3, 'Arunachal Pradesh'),
(4, 'Assam'),
(5, 'Bihar'),
(6, 'Chandigarh (UT)'),
(7, 'Chhattisgarh'),
(8, 'Dadra and Nagar Haveli (UT)'),
(9, 'Daman and Diu (UT)'),
(10, 'Delhi (NCT)'),
(11, 'Goa'),
(12, 'Gujarat'),
(13, 'Haryana'),
(14, 'Himachal Pradesh'),
(15, 'Jammu and Kashmir'),
(16, 'Jharkhand'),
(17, 'Karnataka'),
(18, 'Kerala'),
(19, 'Lakshadweep (UT)'),
(20, 'Madhya Pradesh'),
(21, 'Maharashtra'),
(22, 'Manipur'),
(23, 'Meghalaya'),
(24, 'Mizoram'),
(25, 'Nagaland'),
(26, 'Odisha'),
(27, 'Puducherry (UT)'),
(28, 'Punjab'),
(29, 'Rajastha'),
(30, 'Sikkim'),
(31, 'Tamil Nadu'),
(32, 'Telangana'),
(33, 'Tripura'),
(34, 'Uttarakhand'),
(35, 'EPE'),
(36, 'West Bengal');

-- --------------------------------------------------------

--
-- Table structure for table `userlog`
--

CREATE TABLE `userlog` (
  `id` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `userEmail` varchar(255) NOT NULL,
  `userIp` varbinary(16) NOT NULL,
  `city` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `loginTime` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userlog`
--

INSERT INTO `userlog` (`id`, `userId`, `userEmail`, `userIp`, `city`, `country`, `loginTime`) VALUES
(12, 28, 'anilkumar9557393@gmail.com', 0x3a3a31, '', '', '2019-11-21 07:15:56'),
(13, 29, 'ashwini@gmail.com', 0x3a3a31, '', '', '2019-11-21 07:19:21'),
(14, 28, 'anilkumar9557393@gmail.com', 0x3a3a31, '', '', '2019-11-21 07:26:23'),
(15, 24, 'abhijith080@gmail.com', 0x3a3a31, '', '', '2019-11-21 07:30:22'),
(16, 23, 'anilkumar9557393@gmail.com', 0x3a3a31, '', '', '2019-11-22 04:52:07'),
(17, 29, 'ashwini@gmail.com', 0x3a3a31, '', '', '2019-11-22 05:19:20'),
(18, 28, 'anilkumar9557393@gmail.com', 0x3a3a31, '', '', '2019-11-22 05:44:22'),
(19, 28, 'anilkumar9557393@gmail.com', 0x3a3a31, '', '', '2019-11-22 05:44:34'),
(20, 32, 'jafar@gmail.com', 0x3a3a31, '', '', '2019-11-22 05:48:41'),
(21, 23, 'anilkumar9557393@gmail.com', 0x3a3a31, '', '', '2019-12-02 06:02:05'),
(22, 23, 'anilkumar@gmail.com', 0x3a3a31, '', '', '2019-12-03 07:31:33'),
(23, 23, 'anilkumar@gmail.com', 0x3a3a31, '', '', '2019-12-03 07:34:31'),
(24, 23, 'anilkumar@gmail.com', 0x3a3a31, '', '', '2019-12-03 07:36:09');

-- --------------------------------------------------------

--
-- Table structure for table `userregistration`
--

CREATE TABLE `userregistration` (
  `id` int(11) NOT NULL,
  `regNo` varchar(255) NOT NULL,
  `firstName` varchar(255) NOT NULL,
  `middleName` varchar(255) NOT NULL,
  `lastName` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `contactNo` bigint(20) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `regDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `updationDate` varchar(45) NOT NULL,
  `passUdateDate` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userregistration`
--

INSERT INTO `userregistration` (`id`, `regNo`, `firstName`, `middleName`, `lastName`, `gender`, `contactNo`, `email`, `password`, `regDate`, `updationDate`, `passUdateDate`) VALUES
(23, '1sg17cs018', 'Anil', 'kumar', 'G', 'male', 9113847004, 'anilkumar@gmail.com', 'anilkumar', '2019-11-21 06:43:23', '03-12-2019 01:02:40', ''),
(24, '1sg17cs002', 'Abhijith', 'p', 'Uthaman', 'male', 914345236, 'abhijith080@gmail.com', 'abhijith', '2019-11-21 06:49:57', '', ''),
(25, '1sg17cs019', 'Anirban', '', ' Dey', 'male', 8453413245, 'anirdey2@gmail.com', 'anirban', '2019-11-21 06:55:45', '', ''),
(28, '1sg17cs018', 'Anil', 'kumar', 'G', 'male', 7619214557, 'anilkumar9557393@gmail.com', 'anilkumar', '2019-11-21 07:15:41', '21-11-2019 12:46:04', '21-11-2019 12:46:59');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `logs`
--
ALTER TABLE `logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `registration`
--
ALTER TABLE `registration`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rooms`
--
ALTER TABLE `rooms`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `states`
--
ALTER TABLE `states`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `userlog`
--
ALTER TABLE `userlog`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `userregistration`
--
ALTER TABLE `userregistration`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `logs`
--
ALTER TABLE `logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `registration`
--
ALTER TABLE `registration`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `rooms`
--
ALTER TABLE `rooms`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `states`
--
ALTER TABLE `states`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `userlog`
--
ALTER TABLE `userlog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `userregistration`
--
ALTER TABLE `userregistration`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
